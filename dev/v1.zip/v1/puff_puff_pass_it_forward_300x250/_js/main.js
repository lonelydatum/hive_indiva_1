import indiva from '../../_common/js/indiva.js'
indiva()